import React, { Component } from 'react';
// import PropTypes from 'prop-types';

class Search extends Component {
  constructor(props) {
    super(props);

  }

  componentDidMount() {

  }

  render() {
    return (
      <div>
        search
      </div>
    );
  }
}

// Search.propTypes = {

// };

export default Search;