import React, { Component } from 'react';
// import PropTypes from 'prop-types';

class Account extends Component {
  constructor(props) {
    super(props);

  }

  componentDidMount() {

  }

  render() {
    return (
      <div>
        Account
      </div>
    );
  }
}

// Account.propTypes = {

// };

export default Account;