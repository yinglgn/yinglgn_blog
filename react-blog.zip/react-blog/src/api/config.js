export default {
  baseUrl: {
    dev: 'http://localhost:3000',
    pro: 'https://produce.com'
  },
}